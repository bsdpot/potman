#!/bin/sh
arg1="$1"
arg2="$2"
arg3="$3"
myfile=myfile.txt

if [ ! -z "$arg1" ] && [ ! -z "$arg2" ] && [ ! -z "$arg3" ]; then
    echo "$arg1" >> "$myfile"
    echo "" >> "$myfile"
    echo "$arg2" >> "$myfile"
    echo "" >> "$myfile"
    echo "$arg3" >> "$myfile"
    echo "" >> "$myfile"
    echo "complete" >> "$myfile"
else
    echo "there are no variables set. exiting script."
    exit 1
fi
